package com.entities.cached;

import com.base.entities.Entity;

/**
 * Created by Wafaa on 6/6/2016.
 */
public class Country extends Entity<Country> {

    private Long countryId;
    private String name;

    public Long getCountryId() {
        return countryId;
    }

    public void setCountryId(Long countryId) {
        this.countryId = countryId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
