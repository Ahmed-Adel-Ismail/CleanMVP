package com.entities.cached;

import java.util.LinkedList;

/**
 * Created by Ahmed Adel on 9/21/2016.
 */
public class PickupTimeGroup extends LinkedList<PickupTime> {
}
