package com.entities.cached;

import com.base.entities.ParamsEntity;

/**
 * a class that creates the parameters for login action
 * <p>
 * Created by Ahmed Adel on 11/15/2016.
 */
public class LoginParams extends ParamsEntity<LoginParams> {


    private String username;
    private String password;

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Override
    protected String createGrantType() {
        return "password";
    }
}
