package com.entities;

import com.base.entities.Entity;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

/**
 * Created by Wafaa on 11/14/2016.
 */

public class Notification extends Entity<Notification> implements
        Comparable<Notification>  {

    private long packageId;
    private long pickupRequestId;
    private String notificationItemTitle;
    private String notificationItemBody;
    private String title;
    private String body;
    private Long time;
    private String type;
    private String icon;

    public Notification() {

    }


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        this.time = time;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getNotificationItemTitle() {
        return notificationItemTitle;
    }

    public void setNotificationItemTitle(String notificationItemTitle) {
        this.notificationItemTitle = notificationItemTitle;
    }

    public String getNotificationItemBody() {
        return notificationItemBody;
    }

    public void setNotificationItemBody(String notificationItemBody) {
        this.notificationItemBody = notificationItemBody;
    }

    public String getTimeFormatted(long milliSeconds) {
        String timeFormat = "hh:mm";
        SimpleDateFormat formatter = new SimpleDateFormat(timeFormat, Locale.getDefault());
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(milliSeconds);
        return formatter.format(calendar.getTime());
    }


    public long getPackageId() {
        return packageId;
    }

    public void setPackageId(long packageId) {
        this.packageId = packageId;
    }

    public long getPickupRequestId() {
        return pickupRequestId;
    }

    public void setPickupRequestId(long pickupRequestId) {
        this.pickupRequestId = pickupRequestId;
    }

    @Override
    public boolean equals(Object obj) {
        return this == obj;
    }

    @Override
    public int hashCode() {
        return (int)(Long.valueOf(time)/2);
    }

    @Override
    public int compareTo(Notification o) {
        return o.time.compareTo(this.time);
    }

}
