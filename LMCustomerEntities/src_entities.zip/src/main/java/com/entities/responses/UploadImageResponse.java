package com.entities.responses;

/**
 * A class for handeling the Upload image response
 * <p/>
 * Created by Ahmed Adel on 9/28/2016.
 */
public class UploadImageResponse extends com.base.entities.Entity<UploadImageResponse> {

    private long fileId;

    public long getFileId() {
        return fileId;
    }

    public void setFileId(long fileId) {
        this.fileId = fileId;
    }
}
