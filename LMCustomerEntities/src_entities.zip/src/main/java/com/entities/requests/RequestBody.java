package com.entities.requests;

/**
 * Created by Wafaa on 11/6/2016.
 */

public class RequestBody {

    private long id;

    public RequestBody(long id) {
        this.id = id;
    }
}
