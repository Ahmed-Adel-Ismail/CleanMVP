package com.entities.requests;

/**
 * Created by Wafaa on 11/23/2016.
 */

public class CancelRequestParams {

    private long id;
    private long packageId;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getPackageId() {
        return packageId;
    }

    public void setPackageId(long packageId) {
        this.packageId = packageId;
    }
}
