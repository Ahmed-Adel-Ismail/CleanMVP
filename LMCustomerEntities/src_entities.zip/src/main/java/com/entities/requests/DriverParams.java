package com.entities.requests;

/**
 * Created by Wafaa on 6/26/2016.
 */
public class DriverParams {


    private long companyId = 0;
    private long vehicleId = 810540810;

    public long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(long companyId) {
        this.companyId = companyId;
    }

    public long getVehicleId() {
        return vehicleId;
    }

    public void setVehicleId(long vehicleId) {
        this.vehicleId = vehicleId;
    }
}
