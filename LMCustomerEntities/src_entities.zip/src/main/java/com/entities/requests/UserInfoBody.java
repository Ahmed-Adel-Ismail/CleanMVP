package com.entities.requests;

/**
 * Created by Wafaa on 8/16/2016.
 */
public class UserInfoBody {

    private String userName;


    public void setUserName(String userName) {
        this.userName = userName;
    }
}
