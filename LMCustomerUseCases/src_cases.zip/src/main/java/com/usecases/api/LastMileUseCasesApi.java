package com.usecases.api;

import com.base.abstraction.api.usecases.RequestUrlLocator;
import com.base.abstraction.api.usecases.UseCasesApi;
import com.usecases.requesters.SecureUrlLocator;

/**
 * the implementation for {@link UseCasesApi}
 * <p>
 * Created by Ahmed Adel on 11/14/2016.
 */
public class LastMileUseCasesApi implements UseCasesApi {

    @Override
    public RequestUrlLocator getRequestUrlLocator() {
        return new SecureUrlLocator();
    }
}
