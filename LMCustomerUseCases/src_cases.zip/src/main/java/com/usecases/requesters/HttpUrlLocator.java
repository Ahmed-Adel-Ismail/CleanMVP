package com.usecases.requesters;

import com.base.usecases.requesters.server.generators.ResourcesUrlLocator;
import com.usecases.R;

/**
 * a {@link ResourcesUrlLocator} that generates non-secure {@code http} URLs
 * <p>
 * Created by Ahmed Adel on 10/19/2016.
 */
public class HttpUrlLocator extends ResourcesUrlLocator {

    public HttpUrlLocator() {
        super(R.string.serverProductionUrlHttp, R.string.serverTestUrlHttp);
    }
}
