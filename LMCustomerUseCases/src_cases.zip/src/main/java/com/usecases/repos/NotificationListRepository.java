package com.usecases.repos;

import android.support.annotation.NonNull;

import com.base.abstraction.commands.CommandExecutor;
import com.base.entities.ServerMessage;
import com.base.usecases.events.RequestMessage;
import com.base.usecases.events.ResponseMessage;
import com.base.usecases.repos.base.Repository;
import com.base.usecases.repos.json.JsonRequest;
import com.base.usecases.repos.json.JsonResponse;
import com.base.usecases.requesters.base.EntityGateway;
import com.base.usecases.requesters.base.EntityRequester;
import com.base.usecases.requesters.server.ssl.AuthorizedHttpsRequester;
import com.google.gson.reflect.TypeToken;
import com.usecases.R;
import com.usecases.requesters.SecureUrlLocator;

/**
 * Created by Wafaa on 11/24/2016.
 */

public class NotificationListRepository extends Repository {

    private JsonRequest serverPostRequestCommand;

    @Override
    public void preInitialize() {
        EntityRequester requester = new AuthorizedHttpsRequester(new SecureUrlLocator());
        EntityGateway server = new EntityGateway(requester, this);
        serverPostRequestCommand = new JsonRequest(server);
    }

    @NonNull
    @Override
    protected CommandExecutor<Long, RequestMessage> createOnRequestCommands() {
        CommandExecutor<Long, RequestMessage> commandExecutor = new CommandExecutor<>();
        commandExecutor.put((long) R.id.requestCancelPickupRequest, serverPostRequestCommand);
        return commandExecutor;
    }

    @NonNull
    @Override
    protected CommandExecutor<Long, ResponseMessage> createOnResponseCommands() {
        CommandExecutor<Long, ResponseMessage> commandExecutor = new CommandExecutor<>();
        commandExecutor.put((long) R.id.requestCancelPickupRequest, onCancelRequestResponse());
        return commandExecutor;
    }

    private JsonResponse<ServerMessage> onCancelRequestResponse() {
        return new JsonResponse<ServerMessage>(this) {

            @Override
            protected TypeToken<ServerMessage> getTypeToken() {
                return new TypeToken<ServerMessage>() {
                };
            }
        };
    }

    @Override
    public void onClear() {
        serverPostRequestCommand = null;
    }
}
